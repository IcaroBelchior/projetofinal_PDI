import cv2
import numpy as np
import os

# Criar o diretório "moscas" se não existir
output_dir = "moscas"
os.makedirs(output_dir, exist_ok=True)

# Função para converter a imagem para HSV
def convert_to_hsv(image):
    return cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# Função para segmentar a imagem
def segment_image(image):
    # Aplicar um limiar automático usando o método de Otsu
    _, segmented = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return segmented

# Função para aplicar erosão na imagem
def erode_image(image):
    kernel = np.ones((3, 3), np.uint8)
    return cv2.erode(image, kernel, iterations=1)

# Função para aplicar dilatação na imagem
def dilate_image(image):
    kernel = np.ones((3, 3), np.uint8)
    return cv2.dilate(image, kernel, iterations=1)

# Função para detectar e contar objetos, e desenhar círculos
def detect_and_count_objects(image):
    # Encontrar contornos na imagem
    contours, _ = cv2.findContours(image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Filtrar contornos por área (remover objetos muito pequenos)
    min_area = 100  # Ajuste este valor conforme necessário
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > min_area]
    
    # Filtrar contornos por aspecto (largura/altura)
    aspect_ratio_threshold = 0.5  # Ajuste conforme necessário
    final_contours = []
    for cnt in filtered_contours:
        x, y, w, h = cv2.boundingRect(cnt)
        aspect_ratio = float(w) / h
        if 0.5 <= aspect_ratio <= 2.0:  # Ajuste os limites conforme necessário
            final_contours.append(cnt)
    
    # Desenhar círculos na imagem dilatada
    output_image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    for cnt in final_contours:
        (x, y), radius = cv2.minEnclosingCircle(cnt)
        center = (int(x), int(y))
        radius = int(radius)
        cv2.circle(output_image, center, radius, (0, 255, 0), 2)  # Desenhando o círculo
    
    # Contar o número de objetos detectados
    object_count = len(final_contours)
    
    return output_image, object_count

# Carregar a imagem
image_path = "C:/Users/natan/OneDrive/Documentos/analise/moscas.png"  # Substitua pelo caminho da sua imagem
image = cv2.imread(image_path)

# Verificar se a imagem foi carregada corretamente
if image is None:
    print("Erro: Não foi possível carregar a imagem. Verifique o caminho.")
    exit()
else:
    print("Imagem carregada com sucesso.")

# 1. Converter a imagem para HSV
hsv_image = convert_to_hsv(image)
print("Conversão para HSV concluída.")

# 2. Extrair o canal de valor (V) para melhorar a segmentação
value_channel = hsv_image[:, :, 2]
print("Canal de valor extraído.")

# 3. Segmentar a imagem
segmented_image = segment_image(value_channel)
print("Segmentação concluída.")

# 4. Aplicar erosão para remover ruídos
eroded_image = erode_image(segmented_image)
print("Erosão concluída.")

# 5. Aplicar dilatação para unir regiões próximas
dilated_image = dilate_image(eroded_image)
print("Dilatação concluída.")

# 6. Detectar e contar os objetos e desenhar círculos na imagem dilatada
output_image, object_count = detect_and_count_objects(dilated_image)
print(f"Número de moscas-brancas detectadas: {object_count}")

# Salvar as imagens intermediárias e final no diretório "moscas"
cv2.imwrite(os.path.join(output_dir, 'original_image.jpg'), image)
cv2.imwrite(os.path.join(output_dir, 'segmented_image.jpg'), segmented_image)
cv2.imwrite(os.path.join(output_dir, 'eroded_image.jpg'), eroded_image)
cv2.imwrite(os.path.join(output_dir, 'dilated_image.jpg'), dilated_image)
cv2.imwrite(os.path.join(output_dir, 'detected_objects_with_circles.jpg'), output_image)
print(f"Imagens salvas na pasta '{output_dir}' com sucesso.")

# Exibir as imagens (se o ambiente suportar)
cv2.imshow('Original Image', image)
cv2.imshow('Segmented Image', segmented_image)
cv2.imshow('Eroded Image', eroded_image)
cv2.imshow('Dilated Image', dilated_image)
cv2.imshow('Detected Objects with Circles', output_image)

# Esperar por uma tecla e fechar as janelas
cv2.waitKey(0)
cv2.destroyAllWindows()
