import cv2
import numpy as np
import os

# Função para converter a imagem de RGB para HSV
def convert_to_hsv(image):
    return cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# Função para segmentar a imagem com base em um limiar de cor
def segment_image(hsv_image, lower_bound, upper_bound):
    return cv2.inRange(hsv_image, lower_bound, upper_bound)

# Função para aplicar erosão na imagem segmentada
def apply_erosion(mask, kernel_size=3):
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
    return cv2.erode(mask, kernel, iterations=1)

# Função para detectar e marcar objetos na imagem
def detect_objects(eroded_image, min_area=100):
    contours, _ = cv2.findContours(eroded_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > min_area]
    
    output_image = cv2.cvtColor(eroded_image, cv2.COLOR_GRAY2BGR)  # Convertendo para BGR para colorir os círculos
    for contour in filtered_contours:
        (x, y), radius = cv2.minEnclosingCircle(contour)
        center = (int(x), int(y))
        radius = int(radius)
        cv2.circle(output_image, center, radius, (0, 255, 0), 2)
    
    return output_image, len(filtered_contours)

# Função principal para processar a imagem
def process_image(image_path, lower_bound, upper_bound, output_dir, min_area=100):
    os.makedirs(output_dir, exist_ok=True)
    
    image = cv2.imread(image_path)
    if image is None:
        print(f"Erro: Não foi possível carregar a imagem em {image_path}")
        return

    hsv_image = convert_to_hsv(image)
    mask = segment_image(hsv_image, lower_bound, upper_bound)
    eroded_image = apply_erosion(mask)

    # Chamando detect_objects na imagem erodida
    result_image, num_objects = detect_objects(eroded_image, min_area)

    # Salvando o resultado com a erosão aplicada e círculos
    cv2.imwrite(os.path.join(output_dir, "result_eroded_image_with_circles.png"), result_image)
    print(f"Número de objetos detectados (após erosão): {num_objects}")
    
    cv2.imshow("Result - Erosion", result_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == "__main__":
    image_path = "C:/Users/natan/OneDrive/Documentos/analise/vacas.png"
    output_dir = "C:/Users/natan/OneDrive/Documentos/analise/vacas"
    lower_bound = np.array([0, 0, 200])
    upper_bound = np.array([180, 30, 255])
    min_area = 100
    
    process_image(image_path, lower_bound, upper_bound, output_dir, min_area)
